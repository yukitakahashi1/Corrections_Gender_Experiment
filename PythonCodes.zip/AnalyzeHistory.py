'''
This code analyzes puzzle moves of the contradiction experiment.
Import history data, analyze the moves, and export
the results to be merged with the other data.
Yuki opened the file on November 1, 2020.
'''

# import libraries
import os
import pandas as pd
import time

# keep running time
start_time = time.time()

# change path
codepath = '/Users/yuki/MySync/Research/Correction/Code_Analysis'
os.chdir(codepath)


# define puzzles played in part 1
def puzzle_to_play_pt1(formatting):
    my_boards = [
        [[1, 2, 3], [4, 5, 6], [7, None, 8]],
        [[1, 2, 3], [4, None, 5], [7, 8, 6]],
        [[1, 2, 3], [4, 6, None], [7, 5, 8]],
        [[None, 2, 3], [1, 4, 5], [7, 8, 6]],
        [[1, 3, 6], [4, 2, None], [7, 5, 8]],
        [[1, 2, 3], [7, 4, 6], [5, 8, None]],
        [[1, 2, 3], [7, 4, None], [5, 8, 6]],
        [[2, 5, 3], [1, 7, 6], [4, 8, None]],
        [[4, 1, 3], [7, 2, None], [8, 6, 5]],
        [[None, 1, 3], [5, 2, 7], [4, 8, 6]],
        [[2, None, 6], [1, 3, 8], [4, 5, 7]],
        [[4, 1, None], [8, 3, 2], [5, 7, 6]],
        [[1, 5, 2], [None, 7, 6], [3, 4, 8]],
        [[2, 3, 8], [7, 1, 4], [None, 6, 5]],
        [[2, 7, 3], [5, 1, None], [4, 8, 6]],
    ]
    if formatting == 0:  # returns board
        return my_boards
    if formatting == 1:  # returns string
        my_boards_str = []
        for k in range(0, 15):
            my_puzzle_str = ''
            for i in range(0, 3):
                for j in range(0, 3):
                    my_puzzle_str = my_puzzle_str + str(my_boards[k][i][j])
            my_puzzle_str = my_puzzle_str.replace('None', '_')
            my_boards_str.append(my_puzzle_str)
        return my_boards_str


# define puzzles played in part 2
def puzzle_to_play_pt2(round_number, formatting):
    if round_number == 1:
        my_puzzle = [[2, 4, 3], [1, 5, 6], [7, 8, None]]
    if round_number == 2:
        my_puzzle = [[None, 1, 5], [4, 3, 2], [7, 8, 6]]
    if round_number == 3:
        my_puzzle = [[2, 3, None], [1, 8, 5], [4, 7, 6]]
    if round_number == 4:
        my_puzzle = [[1, 6, 2], [4, 3, 8], [7, 5, None]]
    if round_number == 5:
        my_puzzle = [[1, 3, 6], [5, 2, 8], [4, 7, None]]
    if round_number == 6:
        my_puzzle = [[1, 2, 3], [5, 6, 8], [None, 4, 7]]
    if round_number == 7:
        my_puzzle = [[4, 1, 3], [7, None, 6], [5, 2, 8]]
    if formatting == 0:  # returns board
        return my_puzzle
    if formatting == 1:  # returns string
        my_puzzle_str = ''
        for i in range(0, 3):
            for j in range(0, 3):
                my_puzzle_str = my_puzzle_str + str(my_puzzle[i][j])
        my_puzzle_str = my_puzzle_str.replace('None', '_')
        return my_puzzle_str


# define puzzles played in part 3
def puzzle_to_play_pt3(round_number, formatting):
    if round_number == 1:
        my_puzzle = [[1, 2, None], [7, 5, 3], [8, 4, 6]]
    if round_number == 2:
        my_puzzle = [[4, 1, 2], [7, 5, 3], [8, 6, None]]
    if round_number == 3:
        my_puzzle = [[1, 2, 3], [None, 7, 4], [8, 6, 5]]
    if round_number == 4:
        my_puzzle = [[1, 2, 3], [5, 8, 7], [4, None, 6]]
    if round_number == 5:
        my_puzzle = [[2, 7, 3], [1, None, 6], [5, 4, 8]]
    if round_number == 6:
        my_puzzle = [[5, 1, 3], [4, None, 6], [7, 2, 8]]
    if round_number == 7:
        my_puzzle = [[1, 5, 2], [7, 3, 6], [8, None, 4]]
    if round_number == 8:
        my_puzzle = [[1, 2, 3], [None, 7, 6], [8, 5, 4]]
    if round_number == 9:
        my_puzzle = [[1, 7, 3], [4, None, 5], [8, 2, 6]]
    if round_number == 10:
        my_puzzle = [[2, 3, 6], [4, None, 5], [7, 1, 8]]
    if round_number == 11:
        my_puzzle = [[2, 3, 6], [7, 5, None], [1, 4, 8]]
    if round_number == 12:
        my_puzzle = [[1, 3, 4], [None, 7, 2], [8, 6, 5]]
    if round_number == 13:
        my_puzzle = [[4, 6, 1], [7, None, 2], [5, 8, 3]]
    if round_number == 14:
        my_puzzle = [[7, 4, 1], [3, None, 2], [8, 5, 6]]
    if round_number == 15:
        my_puzzle = [[7, 1, 3], [None, 2, 4], [6, 5, 8]]
    if round_number == 16:
        my_puzzle = [[4, 1, 2], [None, 3, 6], [8, 5, 7]]
    if round_number == 17:
        my_puzzle = [[4, 3, 1], [7, 6, 2], [5, 8, None]]
    if round_number == 18:
        my_puzzle = [[None, 4, 1], [3, 8, 5], [7, 6, 2]]
    if round_number == 19:
        my_puzzle = [[1, 3, 2], [4, 6, None], [7, 8, 5]]
    if round_number == 20:
        my_puzzle = [[7, 4, 1], [None, 3, 2], [6, 8, 5]]
    if formatting == 0:  # returns board
        return my_puzzle
    if formatting == 1:  # returns string
        my_puzzle_str = ''
        for i in range(0, 3):
            for j in range(0, 3):
                my_puzzle_str = my_puzzle_str + str(my_puzzle[i][j])
        my_puzzle_str = my_puzzle_str.replace('None', '_')
        return my_puzzle_str


# define a function to check moves of each puzzle for part 1
def check_moves(df):
    import json
    import copy
    import bfs
    def listToString(s):  # a function to convert list to string
        str1 = ""
        return str1.join(s)
    # create lists in which I store move analysis results for each player
    histories_good_bad = []
    total_moves = [0] * len(df['pt1.1.player.puzzle_histories'])
    total_net_good = [0] * len(df['pt1.1.player.puzzle_histories'])
    # loop over players
    for j in range(0, len(df['pt1.1.player.puzzle_histories'])):
        histories = json.loads(df['pt1.1.player.puzzle_histories'][j])
        print(histories)
        histories_list = []
        for k in range(0, 15):
            histories_list.append(
                [[move['from'], move['to']] for move in histories[k]])
        print('DETERMINE WHETHER EACH MOVE IS GOOD OR BAD')
        moves_list = []  # store good and bad moves. 1: good, -1: bad.
        for k in range(0, 15):
            moves = []
            # initial board:
            current_board = puzzle_to_play_pt1(formatting=1)[k]
            print('INITIAL PUZZLE FOR THIS ROUND:', current_board)
            while len(histories_list[k]) > 0:
                current_board_li = list(current_board)  # convert to list
                new_board_li = copy.deepcopy(current_board_li)
                # move from [0,0]
                if histories_list[k][0] == [[0, 0], [0, 1]]:
                    new_board_li[0] = current_board_li[1]
                    new_board_li[1] = current_board_li[0]
                if histories_list[k][0] == [[0, 0], [1, 0]]:
                    new_board_li[0] = current_board_li[3]
                    new_board_li[3] = current_board_li[0]
                # move from [0,1]
                if histories_list[k][0] == [[0, 1], [0, 0]]:
                    new_board_li[1] = current_board_li[0]
                    new_board_li[0] = current_board_li[1]
                if histories_list[k][0] == [[0, 1], [0, 2]]:
                    new_board_li[1] = current_board_li[2]
                    new_board_li[2] = current_board_li[1]
                if histories_list[k][0] == [[0, 1], [1, 1]]:
                    new_board_li[1] = current_board_li[4]
                    new_board_li[4] = current_board_li[1]
                # move from [0,2]
                if histories_list[k][0] == [[0, 2], [0, 1]]:
                    new_board_li[2] = current_board_li[1]
                    new_board_li[1] = current_board_li[2]
                if histories_list[k][0] == [[0, 2], [1, 2]]:
                    new_board_li[2] = current_board_li[5]
                    new_board_li[5] = current_board_li[2]
                # move from [1,0]
                if histories_list[k][0] == [[1, 0], [0, 0]]:
                    new_board_li[3] = current_board_li[0]
                    new_board_li[0] = current_board_li[3]
                if histories_list[k][0] == [[1, 0], [1, 1]]:
                    new_board_li[3] = current_board_li[4]
                    new_board_li[4] = current_board_li[3]
                if histories_list[k][0] == [[1, 0], [2, 0]]:
                    new_board_li[3] = current_board_li[6]
                    new_board_li[6] = current_board_li[3]
                # move from [1,1]
                if histories_list[k][0] == [[1, 1], [0, 1]]:
                    new_board_li[4] = current_board_li[1]
                    new_board_li[1] = current_board_li[4]
                if histories_list[k][0] == [[1, 1], [1, 0]]:
                    new_board_li[4] = current_board_li[3]
                    new_board_li[3] = current_board_li[4]
                if histories_list[k][0] == [[1, 1], [1, 2]]:
                    new_board_li[4] = current_board_li[5]
                    new_board_li[5] = current_board_li[4]
                if histories_list[k][0] == [[1, 1], [2, 1]]:
                    new_board_li[4] = current_board_li[7]
                    new_board_li[7] = current_board_li[4]
                # move from [1,2]
                if histories_list[k][0] == [[1, 2], [0, 2]]:
                    new_board_li[5] = current_board_li[2]
                    new_board_li[2] = current_board_li[5]
                if histories_list[k][0] == [[1, 2], [1, 1]]:
                    new_board_li[5] = current_board_li[4]
                    new_board_li[4] = current_board_li[5]
                if histories_list[k][0] == [[1, 2], [2, 2]]:
                    new_board_li[5] = current_board_li[8]
                    new_board_li[8] = current_board_li[5]
                # move from [2,0]
                if histories_list[k][0] == [[2, 0], [1, 0]]:
                    new_board_li[6] = current_board_li[3]
                    new_board_li[3] = current_board_li[6]
                if histories_list[k][0] == [[2, 0], [2, 1]]:
                    new_board_li[6] = current_board_li[7]
                    new_board_li[7] = current_board_li[6]
                # move from [2,1]
                if histories_list[k][0] == [[2, 1], [1, 1]]:
                    new_board_li[7] = current_board_li[4]
                    new_board_li[4] = current_board_li[7]
                if histories_list[k][0] == [[2, 1], [2, 0]]:
                    new_board_li[7] = current_board_li[6]
                    new_board_li[6] = current_board_li[7]
                if histories_list[k][0] == [[2, 1], [2, 2]]:
                    new_board_li[7] = current_board_li[8]
                    new_board_li[8] = current_board_li[7]
                # move from [2,2]
                if histories_list[k][0] == [[2, 2], [1, 2]]:
                    new_board_li[8] = current_board_li[5]
                    new_board_li[5] = current_board_li[8]
                if histories_list[k][0] == [[2, 2], [2, 1]]:
                    new_board_li[8] = current_board_li[7]
                    new_board_li[7] = current_board_li[8]
                new_board = listToString(new_board_li)  # convert back to string
                counter_current = bfs.bfsearch(current_board)
                counter_new = bfs.bfsearch(new_board)
                if abs(counter_new - counter_current) > 1:
                    print('ERROR OCCURRED! A MOVE CANNOT CHANGE THE STATE LARGER THAN 1')
                moves.append(counter_current - counter_new)
                histories_list[k] = histories_list[k][1:]
                current_board = new_board
                print('PUZZLE AFTER A MOVE:', current_board)
            moves_list.append(moves)
        print("CALCULATE THE PLAYER'S TOTAL MOVES AND NET GOOD MOVES")
        for k in range(0, 15):
            if len(moves_list[k]) >= 1:
                total_moves[j] += len(moves_list[k])
                total_net_good[j] += sum(moves_list[k])
        histories_good_bad.append(str(moves_list))  # store the whole history list as a string
    print('APPEND THE ANALYSIS RESULTS TO THE INPUTTED DATA FRAME')
    df['pt1.1.player.histories_good_bad'] = histories_good_bad
    df['pt1.1.player.total_moves'] = total_moves
    df['pt1.1.player.total_net_good'] = total_net_good
    df = df.drop(columns=['pt1.1.player.puzzle_histories'])
    return df


# define a function to check moves of each puzzle for parts 2 and 3
def check_contradict_contribute(df, rd, pt):
    import json
    import copy
    import bfs
    def listToString(s):  # a function to convert list to string
        str1 = ""
        return str1.join(s)
    # create lists in which I store move analysis results for each pair
    history_reversion = []  # store the reversion history as a string
    history_good_bad = []  # store the whole history as a string
    total_moves = [0] * len(df['move_history'])
    contradict_p1 = [0] * len(df['move_history'])
    contradict_good_p1 = [0] * len(df['move_history'])
    contradict_bad_p1 = [0] * len(df['move_history'])
    contradict_p2 = [0] * len(df['move_history'])
    contradict_good_p2 = [0] * len(df['move_history'])
    contradict_bad_p2 = [0] * len(df['move_history'])
    good_moves_p1 = [0] * len(df['move_history'])
    bad_moves_p1 = [0] * len(df['move_history'])
    good_moves_p2 = [0] * len(df['move_history'])
    bad_moves_p2 = [0] * len(df['move_history'])
    insisting = [0] * len(df['move_history'])
    if pt == 2:
        contribution_p1 = [0] * len(df['move_history'])
        contribution_p2 = [0] * len(df['move_history'])
    # loop over pairs
    for j in range(0, len(df['move_history'])):
        history = json.loads(df['move_history'][j])
        print(history)
        history_list = [[move['from'], move['to']] for move in history]
        print(history_list)
        print('CALCULATE REVERSIONS')
        history_list_rev = copy.deepcopy(history_list)
        reversion = []  # store reversions. 1: reverse, 0: not.
        for i in range(0, len(history_list_rev)):
            history_list_rev[
                i].reverse()  # reverse history_list's from and to entries
        for i in range(0, len(history_list_rev) - 1):
            if history_list[i] == history_list_rev[i + 1]:
                reversion.append(1)
            else:
                reversion.append(0)
        print('DETERMINE WHETHER EACH MOVE IS GOOD OR BAD')
        # initial board:
        if pt == 2:
            current_board = puzzle_to_play_pt2(round_number=rd, formatting=1)
        if pt == 3:
            current_board = puzzle_to_play_pt3(round_number=rd, formatting=1)
        print('INITIAL PUZZLE FOR THIS ROUND:', current_board)
        moves = []  # store good and bad moves. 1: good, -1: bad.
        while len(history_list) > 0:
            current_board_li = list(current_board)  # convert to list
            new_board_li = copy.deepcopy(current_board_li)
            # move from [0,0]
            if history_list[0] == [[0, 0], [0, 1]]:
                new_board_li[0] = current_board_li[1]
                new_board_li[1] = current_board_li[0]
            if history_list[0] == [[0, 0], [1, 0]]:
                new_board_li[0] = current_board_li[3]
                new_board_li[3] = current_board_li[0]
            # move from [0,1]
            if history_list[0] == [[0, 1], [0, 0]]:
                new_board_li[1] = current_board_li[0]
                new_board_li[0] = current_board_li[1]
            if history_list[0] == [[0, 1], [0, 2]]:
                new_board_li[1] = current_board_li[2]
                new_board_li[2] = current_board_li[1]
            if history_list[0] == [[0, 1], [1, 1]]:
                new_board_li[1] = current_board_li[4]
                new_board_li[4] = current_board_li[1]
            # move from [0,2]
            if history_list[0] == [[0, 2], [0, 1]]:
                new_board_li[2] = current_board_li[1]
                new_board_li[1] = current_board_li[2]
            if history_list[0] == [[0, 2], [1, 2]]:
                new_board_li[2] = current_board_li[5]
                new_board_li[5] = current_board_li[2]
            # move from [1,0]
            if history_list[0] == [[1, 0], [0, 0]]:
                new_board_li[3] = current_board_li[0]
                new_board_li[0] = current_board_li[3]
            if history_list[0] == [[1, 0], [1, 1]]:
                new_board_li[3] = current_board_li[4]
                new_board_li[4] = current_board_li[3]
            if history_list[0] == [[1, 0], [2, 0]]:
                new_board_li[3] = current_board_li[6]
                new_board_li[6] = current_board_li[3]
            # move from [1,1]
            if history_list[0] == [[1, 1], [0, 1]]:
                new_board_li[4] = current_board_li[1]
                new_board_li[1] = current_board_li[4]
            if history_list[0] == [[1, 1], [1, 0]]:
                new_board_li[4] = current_board_li[3]
                new_board_li[3] = current_board_li[4]
            if history_list[0] == [[1, 1], [1, 2]]:
                new_board_li[4] = current_board_li[5]
                new_board_li[5] = current_board_li[4]
            if history_list[0] == [[1, 1], [2, 1]]:
                new_board_li[4] = current_board_li[7]
                new_board_li[7] = current_board_li[4]
            # move from [1,2]
            if history_list[0] == [[1, 2], [0, 2]]:
                new_board_li[5] = current_board_li[2]
                new_board_li[2] = current_board_li[5]
            if history_list[0] == [[1, 2], [1, 1]]:
                new_board_li[5] = current_board_li[4]
                new_board_li[4] = current_board_li[5]
            if history_list[0] == [[1, 2], [2, 2]]:
                new_board_li[5] = current_board_li[8]
                new_board_li[8] = current_board_li[5]
            # move from [2,0]
            if history_list[0] == [[2, 0], [1, 0]]:
                new_board_li[6] = current_board_li[3]
                new_board_li[3] = current_board_li[6]
            if history_list[0] == [[2, 0], [2, 1]]:
                new_board_li[6] = current_board_li[7]
                new_board_li[7] = current_board_li[6]
            # move from [2,1]
            if history_list[0] == [[2, 1], [1, 1]]:
                new_board_li[7] = current_board_li[4]
                new_board_li[4] = current_board_li[7]
            if history_list[0] == [[2, 1], [2, 0]]:
                new_board_li[7] = current_board_li[6]
                new_board_li[6] = current_board_li[7]
            if history_list[0] == [[2, 1], [2, 2]]:
                new_board_li[7] = current_board_li[8]
                new_board_li[8] = current_board_li[7]
            # move from [2,2]
            if history_list[0] == [[2, 2], [1, 2]]:
                new_board_li[8] = current_board_li[5]
                new_board_li[5] = current_board_li[8]
            if history_list[0] == [[2, 2], [2, 1]]:
                new_board_li[8] = current_board_li[7]
                new_board_li[7] = current_board_li[8]
            new_board = listToString(new_board_li)  # convert back to string
            counter_current = bfs.bfsearch(current_board)
            counter_new = bfs.bfsearch(new_board)
            if abs(counter_new - counter_current) > 1:
                print('ERROR OCCURRED! A MOVE CANNOT CHANGE THE STATE LARGER THAN 1')
            moves.append(counter_current - counter_new)
            history_list = history_list[1:]
            current_board = new_board
            print('PUZZLE AFTER A MOVE:', current_board)
        print('CALCULATE GOOD AND BAD REVERSIONS')
        reversion_good_bad = []  # store whether a reversion is good or bad. 1: good, -1: bad, 0: no reversion.
        for i in range(0, len(reversion)):
            if reversion[i] == 1 and moves[i] == -1:
                reversion_good_bad.append(1)  # good reversion
            elif reversion[i] == 1 and moves[i] == 1:
                reversion_good_bad.append(-1)  # bad reversion
            else:
                reversion_good_bad.append(0)  # no reversion
        print("CALCULATE EACH PLAYER'S GOOD AND BAD MOVES")
        if len(moves) >= 1:
            good_moves_p1[j] = moves[::2].count(1)  # odd elements in moves & =1
            good_moves_p2[j] = moves[1::2].count(1)  # even elements in moves & =1
            bad_moves_p1[j] = moves[::2].count(-1)  # odd elements in moves & =-1
            bad_moves_p2[j] = moves[1::2].count(-1)  # even elements in moves & =-1
        print('CALCULATE NUMBER OF CONTRADICTIONS EACH PLAYER GET')
        if len(reversion) >= 1:
            contradict_p1[j] = sum(reversion[::2])  # odd elements of reversion
            contradict_good_p1[j] = reversion_good_bad[::2].count(1)
            contradict_bad_p1[j] = reversion_good_bad[::2].count(-1)
            contradict_p2[j] = sum(reversion[1::2])  # even elements of reversion
            contradict_good_p2[j] = reversion_good_bad[1::2].count(1)
            contradict_bad_p2[j] = reversion_good_bad[1::2].count(-1)
            if len(reversion) >= 2 and any(i == j and i == 1 for i, j in
                                           zip(reversion, reversion[1:])):
                insisting[j] = 1
            else:
                insisting[j] = 0
        history_reversion.append(str(reversion))  # store the reversion history as a string
        history_good_bad.append(str(moves))  # store the whole history as a string
        total_moves[j] = len(moves)
        if pt == 2:
            print("CALCULATE EACH PLAYER'S TOTAL CONTRIBUTION - ONLY FOR PT2")
            if len(moves) >= 1:
                if sum(moves[::2]) <= 0 and sum(moves[1::2]) <= 0:
                    contribution_p1[j] = 0
                    contribution_p2[j] = 0
                if sum(moves[::2]) <= 0 and sum(moves[1::2]) > 0:
                    contribution_p1[j] = 0
                    contribution_p2[j] = 1
                if sum(moves[::2]) > 0 and sum(moves[1::2]) <= 0:
                    contribution_p1[j] = 1
                    contribution_p2[j] = 0
                if sum(moves[::2]) > 0 and sum(moves[1::2]) > 0:
                    contribution_p1[j] = sum(moves[::2]) / sum(moves)  # numerator is odd elements in moves
                    contribution_p2[j] = sum(moves[1::2]) / sum(moves)  # numerator is even elements in moves
    print('APPEND THE ANALYSIS RESULTS TO THE INPUTTED DATA FRAME')
    history_reversion_vname = f"pt{pt}.{rd}.group.history_reversion"
    history_good_bad_vname = f"pt{pt}.{rd}.group.history_good_bad"
    contradict_p1_vname = f"pt{pt}.{rd}.group.contradict_p1"
    contradict_good_p1_vname = f"pt{pt}.{rd}.group.contradict_good_p1"
    contradict_bad_p1_vname = f"pt{pt}.{rd}.group.contradict_bad_p1"
    contribution_p1_vname = f"pt{pt}.{rd}.group.contribution_p1"
    contradict_p2_vname = f"pt{pt}.{rd}.group.contradict_p2"
    contradict_good_p2_vname = f"pt{pt}.{rd}.group.contradict_good_p2"
    contradict_bad_p2_vname = f"pt{pt}.{rd}.group.contradict_bad_p2"
    contribution_p2_vname = f"pt{pt}.{rd}.group.contribution_p2"
    good_moves_p1_vname = f"pt{pt}.{rd}.group.good_moves_p1"
    bad_moves_p1_vname = f"pt{pt}.{rd}.group.bad_moves_p1"
    good_moves_p2_vname = f"pt{pt}.{rd}.group.good_moves_p2"
    bad_moves_p2_vname = f"pt{pt}.{rd}.group.bad_moves_p2"
    total_moves_vname = f"pt{pt}.{rd}.group.total_moves"
    insisting_vname = f"pt{pt}.{rd}.group.insisting"
    df[history_reversion_vname] = history_reversion
    df[history_good_bad_vname] = history_good_bad
    df[contradict_p1_vname] = contradict_p1
    df[contradict_good_p1_vname] = contradict_good_p1
    df[contradict_bad_p1_vname] = contradict_bad_p1
    df[contradict_p2_vname] = contradict_p2
    df[contradict_good_p2_vname] = contradict_good_p2
    df[contradict_bad_p2_vname] = contradict_bad_p2
    df[total_moves_vname] = total_moves
    df[good_moves_p1_vname] = good_moves_p1
    df[bad_moves_p1_vname] = bad_moves_p1
    df[good_moves_p2_vname] = good_moves_p2
    df[bad_moves_p2_vname] = bad_moves_p2
    df[insisting_vname] = insisting
    df = df.drop(columns=['move_history'])
    if pt == 2:
        df[contribution_p1_vname] = contribution_p1
        df[contribution_p2_vname] = contribution_p2
    return df

'''
# load and analyze data for part 1
df = pd.read_excel('HistoryPt1.xlsx')
df_out = check_moves(df)
df_out.to_excel(r'HistoryAnalyzedPt1.xlsx', index=False)
'''

# load and analyze the data for part 2
df_dict = {}
df_dict_out = {}
for i in range(1, 8):
    filename = f'HistoryPt2Rd{i}.xlsx'
    filename_out = f'HistoryAnalyzedPt2Rd{i}.xlsx'
    varname = f'pt2.{i}.group.move_history'
    dfname = 'df' + str(i)
    dfname_out = 'df_out' + str(i)
    if os.path.exists(filename):
        df_dict[dfname] = pd.read_excel(filename)
        df_dict[dfname] = df_dict[dfname].rename(columns={varname: 'move_history'})
        df_dict_out[dfname_out] = check_contradict_contribute(df=df_dict[dfname], rd=i, pt=2)
        df_dict_out[dfname_out].to_excel(filename_out, index=False)

'''
# load and analyze the data for part 3
df_dict = {}
df_dict_out = {}
for i in range(1, 21):
    filename = f'HistoryPt3Rd{i}.xlsx'
    filename_out = f'HistoryAnalyzedPt3Rd{i}.xlsx'
    varname = f'pt3.{i}.group.move_history'
    dfname = 'df' + str(i)
    dfname_out = 'df_out' + str(i)
    if os.path.exists(filename):
        df_dict[dfname] = pd.read_excel(filename)
        df_dict[dfname] = df_dict[dfname].rename(columns={varname: 'move_history'})
        df_dict_out[dfname_out] = check_contradict_contribute(df=df_dict[dfname], rd=i, pt=3)
        df_dict_out[dfname_out].to_excel(filename_out, index=False)
'''
# report running time
print("time elapsed: {:.2f}s".format(time.time() - start_time))