'''
This code analyzes puzzle moves of the contradiction experiment.
Import analyzed history data, expand the moves, and export
the results to be merged with the other data.
Yuki opened the file on February 20, 2021.
'''

# import libraries
import os
import pandas as pd
import time

# keep running time
start_time = time.time()

# change path
codepath = '/Users/yuki/MySync/Research/Correction/Code_Analysis'
os.chdir(codepath)


# define a function to expand each puzzle for parts 2 and 3
def expand_puzzle(df, rd, pt):
    print('EXPAND EACH HISTORY')
    import json
    time_id = []  # identifies round in each session_id
    subsession_id = []  # identifies id_in_subsession
    session_code = []  # identifies session code
    move = []  # include all the history in this list
    reversed = []  # include all the reversed moves in this list
    reversing = []  # include all the reversing moves in this list
    for j in range(0, len(df['history_good_bad'])):
        history_str = df['history_good_bad'][j]
        history = json.loads(history_str)
        move.extend(history)
        reversion_str = df['history_reversion'][j]
        reversion = json.loads(reversion_str)
        reversed.extend(reversion)  # whether a given move is reversed
        reversed.append(0)  # last move cannot be reversed, so set it to 0
        reversing.append(0)  # first move cannot be reversion, so set it to 0
        reversing.extend(reversion)  # whether a given move reverses the previous move
        time_id.extend(list(range(1, len(history)+1)))
        subsession_id.extend([df['id_in_subsession'][j]]*len(history))
        session_code.extend([df['session.code'][j]]*len(history))
    print('COMBINE THE EXPANDED HISTORIES INTO A DATAFRAME')
    time_id_vname = f"pt{pt}.{rd}.group.time_id"
    subsession_id_vname = f"pt{pt}.{rd}.group.id_in_subsession"
    move_vname = f"pt{pt}.{rd}.group.move"
    reversed_vname = f"pt{pt}.{rd}.group.reversed"
    reversing_vname = f"pt{pt}.{rd}.group.reversing"
    df2 = pd.DataFrame()
    df2['session.code'] = session_code
    df2[subsession_id_vname] = subsession_id
    df2[time_id_vname] = time_id
    df2[move_vname] = move
    df2[reversed_vname] = reversed
    df2[reversing_vname] = reversing
    return df2


# load and expand the puzzles for part 2
df_dict = {}
df_dict_out = {}
for i in range(1, 8):
    filename = f'HistoryAnalyzedPt2Rd{i}.xlsx'
    filename_out = f'HistoryExpandedPt2Rd{i}.xlsx'
    varname1 = f'pt2.{i}.group.history_good_bad'
    varname2 = f'pt2.{i}.group.history_reversion'
    varname3 = f'pt2.{i}.group.id_in_subsession'
    dfname = 'df' + str(i)
    dfname_out = 'df_out' + str(i)
    if os.path.exists(filename):
        df_dict[dfname] = pd.read_excel(filename)
        df_dict[dfname] = df_dict[dfname].rename(columns={varname1: 'history_good_bad'})
        df_dict[dfname] = df_dict[dfname].rename(columns={varname2: 'history_reversion'})
        df_dict[dfname] = df_dict[dfname].rename(columns={varname3: 'id_in_subsession'})
        df_dict_out[dfname_out] = expand_puzzle(df=df_dict[dfname], rd=i, pt=2)
        df_dict_out[dfname_out].to_excel(filename_out, index=False)


# report running time
print("time elapsed: {:.2f}s".format(time.time() - start_time))