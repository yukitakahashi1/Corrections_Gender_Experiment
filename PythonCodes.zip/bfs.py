def bfsearch(board, ratio=0):  # ratio = 0 for BFS
    import queue as Queue
    import tiles
    import time
    start_time = time.time()
    game = tiles.TileGame(dim=3)
    closed = {}
    queue = Queue.PriorityQueue()
    orig_cost = game.future_cost(board) * ratio
    orig = (orig_cost, 0, board, None)  # (cost,nMoves,board,parent)
    queue.put(orig)
    closed[orig] = True
    expanded = 0
    solution = None
    if board == game.goal:
        solution = board
    if board != game.goal:
        while queue and not solution:
            parent = queue.get()
            expanded += 1
            (par_cost, par_moves, par_board, ancester) = parent
            empty, moves = game.get_moves(par_board)
            for mov in moves:
                child_board = game.make_move(par_board, empty, mov)
                if closed.get(child_board): continue
                closed[child_board] = True
                child_moves = par_moves + 1
                child_cost = game.future_cost(child_board) * ratio + child_moves
                child = (child_cost, child_moves, child_board, parent)
                queue.put(child)
                # print(child_board)
                if child_board == game.goal:
                    solution = child

    if solution and board != game.goal:
        print(expanded, "entries expanded. Queue still has ", queue.qsize())
        # find the path leading to this solution
        path = []
        while solution:
            path.append(solution[0:3])  # drop the parent
            solution = solution[3]  # to grandparent
        path.reverse()
        end_time = time.time() - start_time
        print("tilesSearch.py: Move=", len(path) - 1, "Search took",
              end_time, "secs")
        # print(path)
        # return path
        return len(path) - 1
    elif solution and board == game.goal:
        print("SOLUTION REACHED!! Move=0")
        return 0
    else:
        return []
